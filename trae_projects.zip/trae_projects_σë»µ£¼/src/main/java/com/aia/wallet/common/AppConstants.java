package com.aia.wallet.common;

public class AppConstants {

    private AppConstants() {
        // Private constructor to prevent instantiation
    }

    public static final String CURRENCY_MMK = "MMK";
    public static final String DATE_FORMAT_ISO = "yyyy-MM-dd";
    public static final String TIME_FORMAT_HH_MM = "HH:mm";

    public static class Csv {
        public static final String EXTENSION = ".csv";
        public static final String HEADER_USER_ID = "User_ID";
        public static final String HEADER_TRANSACTION_TYPE = "Transaction_Type";
        public static final String HEADER_AMOUNT = "Amount";
        public static final String HEADER_CURRENCY = "Currency";
        public static final String HEADER_TRANSACTION_DATE = "Transaction_Date";
        public static final String HEADER_TRANSACTION_DATE_SPACE = "Transaction Date";
        public static final String HEADER_REQUESTED_BY = "Requested_By";
        public static final String HEADER_USER_NAME = "User Name";
        public static final String HEADER_DESCRIPTION = "Description";
        public static final String HEADER_CAMPAIGN_CODE = "Campaign_Code";

        // Report Headers
        public static final String[] REPORT_HEADERS = {
            "No", "Client ID", "User Name", "Transaction Type", "Amount", "Currency", 
            "Campaign Description", "Campign Code", "Transaction Date", "Requested By", 
            "Result", "Error Message"
        };
    }

    public static class Report {
        public static final String DAILY_PREFIX = "Daily_Report_";
        public static final String MONTHLY_PREFIX = "Monthly_Report_";
        public static final String DAILY_PATH = "/reports/daily";
        public static final String MONTHLY_PATH = "/reports/monthly";
        
        public static final String REPORT_TITLE_MONTHLY = "AIA MYANMAR,AIA Monthly Wallet Listing";
        public static final String REPORT_TITLE_DAILY = "AIA MYANMAR,AIA Daily Wallet Listing";
    }

    public static class Batch {
        public static final String CONFIG_KEY_RUN_TIME = "BATCH_RUN_TIME";
        public static final String DEFAULT_RUN_TIME = "18:00";
        public static final String CHECK_INTERVAL_MS_STRING = "60000"; // For @Scheduled annotation
    }

    public static class Messages {
        public static final String ERROR_USER_ID_REQUIRED = "userId is required";
        public static final String ERROR_USER_NOT_FOUND = "User not found";
        public static final String ERROR_INVALID_TRANSACTION_TYPE = "Invalid Transaction Type: ";
        public static final String ERROR_MISSING_DATE = "Missing Transaction Date";
        public static final String ERROR_MISSING_REQUESTED_BY = "Missing Requested By / User Name";
    }
    
    public static class Api {
        public static final String PARAM_USER_ID = "userId";
    }
}
