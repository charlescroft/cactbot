package com.aia.wallet.common;

import com.jcraft.jsch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.Properties;
import java.util.Vector;

@Component
public class SftpUtils {

    private static final Logger log = LoggerFactory.getLogger(SftpUtils.class);

    @Value("${app.sftp.host}")
    private String host;

    @Value("${app.sftp.port}")
    private int port;

    @Value("${app.sftp.username}")
    private String username;

    @Value("${app.sftp.password}")
    private String password;

    /**
     * 从 SFTP 服务器下载文件到本地目录
     *
     * 该方法执行以下步骤：
     * 1. 建立 SFTP 连接
     * 2. 切换到远程目录
     * 3. 确保本地目标目录存在，如果不存在则创建
     * 4. 下载文件到本地路径
     * 5. 关闭连接
     *
     * @param remoteDir 远程 SFTP 服务器上的目录路径
     * @param localDir 本地存储下载文件的目录路径
     * @param fileName 要下载的文件名
     * @throws Exception 如果连接失败、文件不存在或下载过程中发生 IO 错误
     */
    public void downloadFile(String remoteDir, String localDir, String fileName) throws Exception {
        Session session = null;
        ChannelSftp channelSftp = null;
        try {
            // 1. 建立连接
            session = connect();
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();

            // 2. 切换远程目录
            channelSftp.cd(remoteDir);
            
            // 3. 准备本地文件路径
            File localFile = new File(localDir + File.separator + fileName);
            if (!localFile.getParentFile().exists()) {
                localFile.getParentFile().mkdirs();
            }
            
            // 4. 执行下载
            channelSftp.get(fileName, localFile.getAbsolutePath());
            log.info("Downloaded file: {} to {}", fileName, localFile.getAbsolutePath());

        } finally {
            disconnect(channelSftp, session);
        }
    }

    /**
     * 将本地文件上传到 SFTP 服务器
     *
     * 该方法执行以下步骤：
     * 1. 建立 SFTP 连接
     * 2. 尝试切换到远程目录，如果目录不存在则自动创建
     * 3. 将本地文件上传到远程目录
     * 4. 关闭连接
     *
     * @param remoteDir 目标远程目录路径
     * @param localFilePath 本地文件的完整路径
     * @param remoteFileName 上传后在服务器上保存的文件名
     * @throws Exception 如果连接失败、文件读取错误或上传过程中发生网络错误
     */
    public void uploadFile(String remoteDir, String localFilePath, String remoteFileName) throws Exception {
        Session session = null;
        ChannelSftp channelSftp = null;
        try {
            session = connect();
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();

            // 尝试进入远程目录，如果不存在则创建
            try {
                channelSftp.cd(remoteDir);
            } catch (SftpException e) {
                log.warn("Remote directory {} does not exist. Creating it.", remoteDir);
                channelSftp.mkdir(remoteDir);
                channelSftp.cd(remoteDir);
            }

            channelSftp.put(localFilePath, remoteFileName);
            log.info("Uploaded file: {} to {}/{}", localFilePath, remoteDir, remoteFileName);

        } finally {
            disconnect(channelSftp, session);
        }
    }

    /**
     * 列出指定远程目录下的所有 CSV 文件
     *
     * 用于查找每日上传的奖励文件。
     *
     * @param remoteDir 要扫描的远程目录
     * @return 包含文件信息的 Vector 集合，仅包含以 .csv 结尾的文件
     * @throws Exception 如果连接失败或目录无法访问
     */
    public Vector<ChannelSftp.LsEntry> listFiles(String remoteDir) throws Exception {
        Session session = null;
        ChannelSftp channelSftp = null;
        try {
            session = connect();
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();
            
            channelSftp.cd(remoteDir);
            // 仅列出 CSV 文件
            return channelSftp.ls("*.csv");
        } finally {
            disconnect(channelSftp, session);
        }
    }

    private Session connect() throws JSchException {
        JSch jsch = new JSch();
        Session session = jsch.getSession(username, host, port);
        session.setPassword(password);
        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config);
        session.connect();
        return session;
    }

    private void disconnect(ChannelSftp channelSftp, Session session) {
        if (channelSftp != null && channelSftp.isConnected()) {
            channelSftp.disconnect();
        }
        if (session != null && session.isConnected()) {
            session.disconnect();
        }
    }
}
