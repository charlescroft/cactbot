package com.aia.wallet.enums;

public enum TransactionStatus {
    PENDING,
    SUCCESS,
    FAILED
}
