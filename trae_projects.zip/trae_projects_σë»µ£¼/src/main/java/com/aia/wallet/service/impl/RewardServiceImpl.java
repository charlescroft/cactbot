package com.aia.wallet.service.impl;

import com.aia.wallet.common.AppConstants;
import com.aia.wallet.dto.BalanceResponse;
import com.aia.wallet.dto.TransactionResponse;
import com.aia.wallet.entity.RewardTransaction;
import com.aia.wallet.enums.TransactionStatus;
import com.aia.wallet.repository.RewardTransactionRepository;
import com.aia.wallet.service.RewardService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RewardServiceImpl implements RewardService {

    private final RewardTransactionRepository rewardTransactionRepository;

    public RewardServiceImpl(RewardTransactionRepository rewardTransactionRepository) {
        this.rewardTransactionRepository = rewardTransactionRepository;
    }

    @Override
    public BalanceResponse getBalance(String userId) {
        java.time.LocalDate today = java.time.LocalDate.now();
        List<RewardTransaction> transactions = rewardTransactionRepository.findByUserId(userId).stream()
                .filter(tx -> tx.getStatus() == TransactionStatus.SUCCESS)
                .filter(tx -> tx.getExpirationDate() == null || !tx.getExpirationDate().isBefore(today))
                .sorted(Comparator.comparing(RewardTransaction::getUpdatedAt).reversed())
                .collect(Collectors.toList());

        BigDecimal balance = transactions.stream()
                .map(tx -> {
                    if (tx.getTransactionType() == com.aia.wallet.enums.TransactionType.Debit) {
                        return tx.getAmount().negate();
                    }
                    return tx.getAmount();
                })
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        var lastUpdated = transactions.isEmpty() ? null : transactions.get(0).getUpdatedAt();
        var currency = transactions.isEmpty() ? AppConstants.CURRENCY_MMK : transactions.get(0).getCurrency();

        return BalanceResponse.builder()
                .userId(userId)
                .balance(balance)
                .currency(currency)
                .lastUpdatedAt(lastUpdated)
                .build();
    }

    @Override
    public List<TransactionResponse> getTransactionHistory(String userId) {
        return rewardTransactionRepository.findByUserId(userId).stream()
                .filter(tx -> tx.getStatus() == TransactionStatus.SUCCESS)
                .sorted(Comparator.comparing(RewardTransaction::getTransactionDate).reversed())
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    private TransactionResponse toResponse(RewardTransaction tx) {
        return TransactionResponse.builder()
                .transactionId(String.valueOf(tx.getTransactionId()))
                .userId(tx.getUserId())
                .transactionType(tx.getTransactionType().name())
                .amount(tx.getAmount())
                .currency(tx.getCurrency())
                .transactionDate(tx.getTransactionDate())
                .requestedBy(tx.getRequestedBy())
                .campaignDescription(tx.getCampaignDescription())
                .campaignCode(tx.getCampaignCode())
                .effectiveDate(tx.getEffectiveDate())
                .expirationDate(tx.getExpirationDate())
                .build();
    }
}
