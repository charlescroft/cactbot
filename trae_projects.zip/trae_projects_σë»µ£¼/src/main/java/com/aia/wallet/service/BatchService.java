package com.aia.wallet.service;

public interface BatchService {
    void processDailyRewards();
}
