package com.aia.wallet.service.impl;

import com.aia.wallet.common.AppConstants;
import com.aia.wallet.common.SftpUtils;
import com.aia.wallet.entity.OperatorLog;
import com.aia.wallet.entity.RewardTransaction;
import com.aia.wallet.enums.TransactionStatus;
import com.aia.wallet.enums.TransactionType;
import com.aia.wallet.repository.RewardTransactionRepository;
import com.aia.wallet.service.BatchService;
import com.aia.wallet.service.OperatorLogService;
import com.jcraft.jsch.ChannelSftp;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.Vector;

@Service
public class BatchServiceImpl implements BatchService {

    private static final Logger log = LoggerFactory.getLogger(BatchServiceImpl.class);

    private final SftpUtils sftpUtils;
    private final RewardTransactionRepository rewardTransactionRepository;
    private final OperatorLogService operatorLogService;

    @Value("${app.sftp.remote-dir}")
    private String remoteDir;

    @Value("${app.sftp.download-dir}")
    private String downloadDir;

    @Value("${app.sftp.backup-dir}")
    private String backupDir;

    @Value("${app.sftp.username}")
    private String sftpUser;

    public BatchServiceImpl(SftpUtils sftpUtils, RewardTransactionRepository rewardTransactionRepository, OperatorLogService operatorLogService) {
        this.sftpUtils = sftpUtils;
        this.rewardTransactionRepository = rewardTransactionRepository;
        this.operatorLogService = operatorLogService;
    }

    @Override
    public void processDailyRewards() {
        String batchRunId = UUID.randomUUID().toString();
        log.info("Starting batch processing. Batch Run ID: {}", batchRunId);

        try {
            // 1. List files
            Vector<ChannelSftp.LsEntry> files = sftpUtils.listFiles(remoteDir);
            if (files == null || files.isEmpty()) {
                log.info("No CSV files found in {}", remoteDir);
                return;
            }

            for (ChannelSftp.LsEntry fileEntry : files) {
                String filename = fileEntry.getFilename();
                if (!filename.endsWith(AppConstants.Csv.EXTENSION)) continue;

                log.info("Processing file: {}", filename);
                processFile(filename, batchRunId);
            }

        } catch (Exception e) {
            log.error("Error during batch processing", e);
        }
    }

    private void processFile(String filename, String batchRunId) {
        List<OperatorLog> logs = new ArrayList<>();

        try {
            // 2. Download file
            sftpUtils.downloadFile(remoteDir, downloadDir, filename);
            File localFile = new File(downloadDir + File.separator + filename);

            // 3. Parse and Validate
            List<RewardTransaction> transactions = parseCsv(localFile, batchRunId, logs);

            // 4. Save to DB
            saveTransactions(transactions);

            // 5. Save Logs
            operatorLogService.saveBatch(logs);

            // 6. Move to backup (Remote)
            // Ideally we move the remote file to a backup folder
            // sftpUtils.moveFile(remoteDir + "/" + filename, backupDir + "/" + filename);
            // Not implemented in SftpUtils yet, but required.
            
            // Generate Report (Skipped for brevity, would be similar to CSV writing)

        } catch (Exception e) {
            log.error("Failed to process file: " + filename, e);
        }
    }

    @Transactional
    public void saveTransactions(List<RewardTransaction> transactions) {
        rewardTransactionRepository.saveAll(transactions);
    }

    private List<RewardTransaction> parseCsv(File file, String batchRunId, List<OperatorLog> logs) throws Exception {
        List<RewardTransaction> list = new ArrayList<>();
        int successCount = 0;
        int failureCount = 0;

        try (Reader reader = new FileReader(file);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader().withIgnoreHeaderCase().withTrim())) {

            for (CSVRecord record : csvParser) {
                OperatorLog opLog = new OperatorLog();
                opLog.setFilename(file.getName());
                opLog.setBatchRunId(batchRunId);
                opLog.setCreatedAt(LocalDateTime.now());
                opLog.setTransactionDate(LocalDate.now()); // Default, will be updated if valid

                try {
                    RewardTransaction tx = new RewardTransaction();
                    tx.setUserId(record.get(AppConstants.Csv.HEADER_USER_ID));
                    
                    String typeStr = record.get(AppConstants.Csv.HEADER_TRANSACTION_TYPE);
                    boolean typeFound = false;
                    for (TransactionType t : TransactionType.values()) {
                        if (t.name().equalsIgnoreCase(typeStr)) {
                            tx.setTransactionType(t);
                            typeFound = true;
                            break;
                        }
                    }
                    if (!typeFound) {
                         throw new IllegalArgumentException(AppConstants.Messages.ERROR_INVALID_TRANSACTION_TYPE + typeStr);
                    }
                    
                    tx.setAmount(new BigDecimal(record.get(AppConstants.Csv.HEADER_AMOUNT)));
                    tx.setCurrency(record.get(AppConstants.Csv.HEADER_CURRENCY));
                    
                    // Handle date format variations if necessary
                    String dateStr = record.isMapped(AppConstants.Csv.HEADER_TRANSACTION_DATE) ? record.get(AppConstants.Csv.HEADER_TRANSACTION_DATE) : record.get(AppConstants.Csv.HEADER_TRANSACTION_DATE_SPACE);
                    if (dateStr == null) throw new IllegalArgumentException(AppConstants.Messages.ERROR_MISSING_DATE);
                    tx.setTransactionDate(LocalDate.parse(dateStr, DateTimeFormatter.ofPattern(AppConstants.DATE_FORMAT_ISO)));

                    // Handle Requested By
                    String requestedBy = null;
                    if (record.isMapped(AppConstants.Csv.HEADER_REQUESTED_BY)) {
                        requestedBy = record.get(AppConstants.Csv.HEADER_REQUESTED_BY);
                    } else if (record.isMapped(AppConstants.Csv.HEADER_USER_NAME)) {
                        requestedBy = record.get(AppConstants.Csv.HEADER_USER_NAME);
                    }
                    if (requestedBy == null) throw new IllegalArgumentException(AppConstants.Messages.ERROR_MISSING_REQUESTED_BY);
                    tx.setRequestedBy(requestedBy);
                    
                    if (record.isMapped(AppConstants.Csv.HEADER_DESCRIPTION)) tx.setCampaignDescription(record.get(AppConstants.Csv.HEADER_DESCRIPTION));
                    if (record.isMapped(AppConstants.Csv.HEADER_CAMPAIGN_CODE)) tx.setCampaignCode(record.get(AppConstants.Csv.HEADER_CAMPAIGN_CODE));
                    
                    tx.setBatchRunId(batchRunId);
                    tx.setStatus(TransactionStatus.SUCCESS);
                    tx.setOperatorId(sftpUser); // Use SFTP user as Operator ID

                    list.add(tx);
                    successCount++;

                    // Success Log
                    opLog.setStatus(TransactionStatus.SUCCESS);
                    opLog.setOperatorName(tx.getRequestedBy());
                    opLog.setTransactionType(tx.getTransactionType());
                    opLog.setAmount(tx.getAmount());
                    opLog.setClientId(tx.getUserId());
                    opLog.setTransactionDate(tx.getTransactionDate());
                    opLog.setProcessedAt(LocalDateTime.now());
                    
                    // New fields
                    opLog.setCurrency(tx.getCurrency());
                    opLog.setCampaignDescription(tx.getCampaignDescription());
                    opLog.setCampaignCode(tx.getCampaignCode());
                    
                    logs.add(opLog);

                } catch (Exception e) {
                    failureCount++;
                    log.error("Failed to process record number {}: {}", record.getRecordNumber(), e.getMessage());
                    
                    // Failure Log
                    opLog.setStatus(TransactionStatus.FAILED);
                    opLog.setErrorMessage(e.getMessage());
                    opLog.setProcessedAt(LocalDateTime.now());
                    
                    try {
                        if (record.isMapped(AppConstants.Csv.HEADER_USER_ID)) opLog.setClientId(record.get(AppConstants.Csv.HEADER_USER_ID));
                        if (record.isMapped(AppConstants.Csv.HEADER_AMOUNT)) {
                             try { opLog.setAmount(new BigDecimal(record.get(AppConstants.Csv.HEADER_AMOUNT))); } catch (Exception ignore) {}
                        }
                        if (record.isMapped(AppConstants.Csv.HEADER_CURRENCY)) opLog.setCurrency(record.get(AppConstants.Csv.HEADER_CURRENCY));
                        if (record.isMapped(AppConstants.Csv.HEADER_DESCRIPTION)) opLog.setCampaignDescription(record.get(AppConstants.Csv.HEADER_DESCRIPTION));
                        if (record.isMapped(AppConstants.Csv.HEADER_CAMPAIGN_CODE)) opLog.setCampaignCode(record.get(AppConstants.Csv.HEADER_CAMPAIGN_CODE));
                        
                        String rBy = null;
                        if (record.isMapped(AppConstants.Csv.HEADER_REQUESTED_BY)) rBy = record.get(AppConstants.Csv.HEADER_REQUESTED_BY);
                        else if (record.isMapped(AppConstants.Csv.HEADER_USER_NAME)) rBy = record.get(AppConstants.Csv.HEADER_USER_NAME);
                        if (rBy != null) opLog.setOperatorName(rBy);

                        String tStr = record.get(AppConstants.Csv.HEADER_TRANSACTION_TYPE);
                        if (tStr != null) {
                             for (TransactionType t : TransactionType.values()) {
                                if (t.name().equalsIgnoreCase(tStr)) {
                                    opLog.setTransactionType(t);
                                    break;
                                }
                            }
                        }
                    } catch (Exception ignore) {}
                    
                    logs.add(opLog);
                }
            }
        }
        
        log.info("CSV Processing Completed for file: {}. Success: {}, Failure: {}", file.getName(), successCount, failureCount);
        return list;
    }
}
