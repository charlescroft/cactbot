package com.aia.wallet.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class BalanceResponse {
    private String userId;
    private BigDecimal balance;
    private String currency;
    private LocalDateTime lastUpdatedAt;

    public BalanceResponse() {
    }

    public BalanceResponse(String userId, BigDecimal balance, String currency, LocalDateTime lastUpdatedAt) {
        this.userId = userId;
        this.balance = balance;
        this.currency = currency;
        this.lastUpdatedAt = lastUpdatedAt;
    }

    public static BalanceResponseBuilder builder() {
        return new BalanceResponseBuilder();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public LocalDateTime getLastUpdatedAt() {
        return lastUpdatedAt;
    }

    public void setLastUpdatedAt(LocalDateTime lastUpdatedAt) {
        this.lastUpdatedAt = lastUpdatedAt;
    }

    public static class BalanceResponseBuilder {
        private String userId;
        private BigDecimal balance;
        private String currency;
        private LocalDateTime lastUpdatedAt;

        BalanceResponseBuilder() {
        }

        public BalanceResponseBuilder userId(String userId) {
            this.userId = userId;
            return this;
        }

        public BalanceResponseBuilder balance(BigDecimal balance) {
            this.balance = balance;
            return this;
        }

        public BalanceResponseBuilder currency(String currency) {
            this.currency = currency;
            return this;
        }

        public BalanceResponseBuilder lastUpdatedAt(LocalDateTime lastUpdatedAt) {
            this.lastUpdatedAt = lastUpdatedAt;
            return this;
        }

        public BalanceResponse build() {
            return new BalanceResponse(userId, balance, currency, lastUpdatedAt);
        }
    }
}
