package com.aia.wallet.enums;

public enum TransactionType {
    Credit,
    Debit
}
