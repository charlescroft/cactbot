package com.aia.wallet.job;

import com.aia.wallet.common.AppConstants;
import com.aia.wallet.entity.OperatorLog;
import com.aia.wallet.entity.SystemConfig;
import com.aia.wallet.repository.OperatorLogRepository;
import com.aia.wallet.repository.SystemConfigRepository;
import com.aia.wallet.service.BatchService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

@Component
public class BatchJob {

    private static final Logger log = LoggerFactory.getLogger(BatchJob.class);

    private final BatchService batchService;
    private final SystemConfigRepository systemConfigRepository;
    private final OperatorLogRepository operatorLogRepository;

    public BatchJob(BatchService batchService, SystemConfigRepository systemConfigRepository, OperatorLogRepository operatorLogRepository) {
        this.batchService = batchService;
        this.systemConfigRepository = systemConfigRepository;
        this.operatorLogRepository = operatorLogRepository;
    }

    @Scheduled(fixedDelayString = AppConstants.Batch.CHECK_INTERVAL_MS_STRING) // Check every minute
    public void checkAndRunBatch() {
        SystemConfig config = systemConfigRepository.findById(AppConstants.Batch.CONFIG_KEY_RUN_TIME).orElse(null);
        String runTimeStr = (config != null) ? config.getConfigValue() : AppConstants.Batch.DEFAULT_RUN_TIME;
        
        LocalTime runTime = LocalTime.parse(runTimeStr, DateTimeFormatter.ofPattern(AppConstants.TIME_FORMAT_HH_MM));
        LocalTime now = LocalTime.now();

        // Run if current time is after runTime and within a small window (e.g. 5 mins) 
        // to avoid missing it if the job was down exactly at 18:00.
        // AND check if already run today.
        
        if (now.isAfter(runTime) && now.isBefore(runTime.plusMinutes(5))) {
            // Check if already run today
            long count = operatorLogRepository.findAll().stream()
                    .filter(log -> log.getCreatedAt().toLocalDate().equals(LocalDate.now()))
                    .count();
            
            if (count == 0) {
                log.info("Triggering Daily Batch Job at {}", now);
                batchService.processDailyRewards();
            }
        }
    }
}
