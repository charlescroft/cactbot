package com.aia.wallet.service;

import com.aia.wallet.common.AppConstants;
import com.aia.wallet.common.SftpUtils;
import com.aia.wallet.entity.OperatorLog;
import com.aia.wallet.entity.RewardTransaction;
import com.aia.wallet.enums.TransactionStatus;
import com.aia.wallet.repository.OperatorLogRepository;
import com.aia.wallet.repository.RewardTransactionRepository;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.SftpATTRS;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import java.io.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Vector;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@SpringBootTest
@ActiveProfiles("test")
public class BatchReportIntegrationTest {

    @Autowired
    private BatchService batchService;

    @Autowired
    private ReportService reportService;

    @Autowired
    private RewardTransactionRepository rewardTransactionRepository;

    @Autowired
    private OperatorLogRepository operatorLogRepository;

    @MockBean
    private SftpUtils sftpUtils;

    @Value("${app.sftp.download-dir}")
    private String downloadDir;

    @BeforeEach
    void setUp() {
        rewardTransactionRepository.deleteAll();
        operatorLogRepository.deleteAll();
    }

    @Test
    void testDailyBatchAndMonthlyReport() throws Exception {
        // ==========================================
        // 1. Prepare Mock Data (Daily CSV File)
        // ==========================================
        String filename = "Reward_2025-11-24.csv";
        String csvContent = "User_ID,User Name,Transaction_Type,Amount,Currency,Transaction_Date,Requested_By,Description,Campaign_Code\n" +
                "20097740,Hsu Myat,Credit,500,MMK,2025-11-24,Pyae Thuta,Cashback,Q3 promotional campaign reward\n" +
                "20097740,Hsu Myat,Debit,200,MMK,2025-11-24,Pyae Thuta,Cashback,Q3 promotional campaign reward\n" +
                "INVALID_USER,Bad User,UnknownType,100,MMK,2025-11-24,Admin,Error,Test\n"; // Failed Record

        // Mock listFiles
        Vector<ChannelSftp.LsEntry> fileList = new Vector<>();
        ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
        when(entry.getFilename()).thenReturn(filename);
        SftpATTRS attrs = mock(SftpATTRS.class); // If needed
        when(entry.getAttrs()).thenReturn(attrs);
        fileList.add(entry);

        when(sftpUtils.listFiles(anyString())).thenReturn(fileList);

        // Mock downloadFile to write the CSV content to the download directory
        doAnswer(invocation -> {
            String localDir = invocation.getArgument(1);
            String fName = invocation.getArgument(2);
            File file = new File(localDir, fName);
            if (!file.getParentFile().exists()) file.getParentFile().mkdirs();
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(csvContent);
            }
            return null;
        }).when(sftpUtils).downloadFile(anyString(), eq(downloadDir), eq(filename));

        // ==========================================
        // 2. Run Batch Processing
        // ==========================================
        batchService.processDailyRewards();

        // ==========================================
        // 3. Verify Data Storage (DB)
        // ==========================================
        
        // Verify RewardTransactions (Only Success records)
        List<RewardTransaction> transactions = rewardTransactionRepository.findAll();
        assertEquals(2, transactions.size(), "Should have 2 successful transactions");
        
        RewardTransaction creditTx = transactions.stream().filter(t -> t.getTransactionType().name().equals("Credit")).findFirst().orElseThrow();
        assertEquals(new BigDecimal("500.00"), creditTx.getAmount());
        
        RewardTransaction debitTx = transactions.stream().filter(t -> t.getTransactionType().name().equals("Debit")).findFirst().orElseThrow();
        assertEquals(new BigDecimal("200.00"), debitTx.getAmount());

        // Verify OperatorLogs (Success + Failed)
        List<OperatorLog> logs = operatorLogRepository.findAll();
        assertEquals(3, logs.size(), "Should have 3 logs (2 success + 1 failed)");
        
        long successCount = logs.stream().filter(l -> l.getStatus() == TransactionStatus.SUCCESS).count();
        assertEquals(2, successCount);
        
        long failedCount = logs.stream().filter(l -> l.getStatus() == TransactionStatus.FAILED).count();
        assertEquals(1, failedCount);
        
        OperatorLog failedLog = logs.stream().filter(l -> l.getStatus() == TransactionStatus.FAILED).findFirst().orElseThrow();
        assertNotNull(failedLog.getErrorMessage());
        assertTrue(failedLog.getErrorMessage().contains("Invalid Transaction Type"), "Error message should indicate invalid type");

        // ==========================================
        // 4. Run Monthly Report Generation
        // ==========================================
        LocalDate reportMonth = LocalDate.of(2025, 11, 1);
        
        ArgumentCaptor<String> localFilePathCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> remoteFileNameCaptor = ArgumentCaptor.forClass(String.class);
        
        reportService.generateAndUploadMonthlyReport(reportMonth);

        // ==========================================
        // 5. Verify Report Content
        // ==========================================
        verify(sftpUtils).uploadFile(eq(AppConstants.Report.MONTHLY_PATH), localFilePathCaptor.capture(), remoteFileNameCaptor.capture());
        
        String uploadedFilePath = localFilePathCaptor.getValue();
        File uploadedFile = new File(uploadedFilePath);
        
        // Note: The file might be deleted by the service after upload.
        // However, in our mock verify, we capture the path.
        // The service deletes it *after* uploadFile returns.
        // Since our mock doesn't actually upload, the file should still exist IF the service didn't delete it yet?
        // Wait, service code: 
        // sftpUtils.uploadFile(...);
        // Files.deleteIfExists(file.toPath());
        // So the file IS deleted.
        // But wait, I mocked uploadFile. The delete happens AFTER the mock returns.
        // So when I verify, the method has already returned, so the file IS deleted.
        // I cannot read the file content here because it's gone.
        
        // To verify content, I should capture it inside the mock of uploadFile!
        
        // Let's redefine the mock for uploadFile to read content before returning.
    }
    
    @Test
    void testReportContentVerification() throws Exception {
        // Setup Data directly in DB
        OperatorLog log1 = new OperatorLog();
        log1.setClientId("20097740");
        log1.setTransactionType(com.aia.wallet.enums.TransactionType.Credit);
        log1.setAmount(new BigDecimal("500.00"));
        log1.setCurrency("MMK");
        log1.setTransactionDate(LocalDate.of(2025, 11, 24));
        log1.setStatus(TransactionStatus.SUCCESS);
        log1.setOperatorName("Pyae Thuta");
        log1.setCampaignDescription("Cashback");
        log1.setCampaignCode("Q3");
        operatorLogRepository.save(log1);

        OperatorLog log2 = new OperatorLog();
        log2.setClientId("20097740");
        log2.setTransactionType(com.aia.wallet.enums.TransactionType.Debit);
        log2.setAmount(new BigDecimal("500.00")); // Note: Log stores raw amount
        log2.setCurrency("MMK");
        log2.setTransactionDate(LocalDate.of(2025, 11, 24));
        log2.setStatus(TransactionStatus.FAILED); // Failed record
        log2.setOperatorName("Pyae Thuta");
        log2.setErrorMessage("Some Error");
        operatorLogRepository.save(log2);

        final StringBuilder uploadedContent = new StringBuilder();

        doAnswer(invocation -> {
            String path = invocation.getArgument(1);
            try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    uploadedContent.append(line).append("\n");
                }
            }
            return null;
        }).when(sftpUtils).uploadFile(anyString(), anyString(), anyString());

        reportService.generateAndUploadMonthlyReport(LocalDate.of(2025, 11, 1));

        String csv = uploadedContent.toString();
        System.out.println("Generated CSV:\n" + csv);

        assertTrue(csv.contains("AIA MYANMAR,AIA Monthly Wallet Listing"));
        assertTrue(csv.contains("No,Client ID,User Name"));
        assertTrue(csv.contains("Passed"));
        assertTrue(csv.contains("Failed"));
        assertTrue(csv.contains("Some Error"));
    }

    @Test
    void testProcessFromResourceFile() throws Exception {
        // ==========================================
        // 1. Read CSV Content from Resources
        // ==========================================
        String resourceFilename = "mock_daily_report.csv";
        StringBuilder csvContentBuilder = new StringBuilder();
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(resourceFilename);
             BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {
            String line;
            while ((line = reader.readLine()) != null) {
                csvContentBuilder.append(line).append("\n");
            }
        }
        String csvContent = csvContentBuilder.toString();
        assertFalse(csvContent.isEmpty(), "Resource file should not be empty");

        String filename = "Reward_Resource_Test.csv";

        // ==========================================
        // 2. Mock SFTP Interactions
        // ==========================================
        
        // Mock listFiles
        Vector<ChannelSftp.LsEntry> fileList = new Vector<>();
        ChannelSftp.LsEntry entry = mock(ChannelSftp.LsEntry.class);
        when(entry.getFilename()).thenReturn(filename);
        SftpATTRS attrs = mock(SftpATTRS.class); 
        when(entry.getAttrs()).thenReturn(attrs);
        fileList.add(entry);

        when(sftpUtils.listFiles(anyString())).thenReturn(fileList);

        // Mock downloadFile to write the resource content
        doAnswer(invocation -> {
            String localDir = invocation.getArgument(1);
            String fName = invocation.getArgument(2);
            File file = new File(localDir, fName);
            if (!file.getParentFile().exists()) file.getParentFile().mkdirs();
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(csvContent);
            }
            return null;
        }).when(sftpUtils).downloadFile(anyString(), eq(downloadDir), eq(filename));

        // ==========================================
        // 3. Run Batch Processing
        // ==========================================
        batchService.processDailyRewards();

        // ==========================================
        // 4. Verify Data Storage
        // ==========================================
        
        // Check Transactions (Success records from mock_daily_report.csv)
        // The file has 2 success records: Credit 500, Debit 200
        List<RewardTransaction> transactions = rewardTransactionRepository.findAll();
        assertEquals(2, transactions.size());
        
        RewardTransaction creditTx = transactions.stream()
                .filter(t -> t.getTransactionType().name().equals("Credit"))
                .findFirst().orElseThrow();
        assertEquals(new BigDecimal("500.00"), creditTx.getAmount());
        
        // Check Logs (Success + Failed)
        // The file has 1 failed record
        List<OperatorLog> logs = operatorLogRepository.findAll();
        assertEquals(3, logs.size());
        
        long failedCount = logs.stream().filter(l -> l.getStatus() == TransactionStatus.FAILED).count();
        assertEquals(1, failedCount);
    }
}
