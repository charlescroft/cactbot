package com.aia.wallet.service;

import com.aia.wallet.dto.BalanceResponse;
import com.aia.wallet.dto.TransactionResponse;
import com.aia.wallet.entity.RewardTransaction;
import com.aia.wallet.enums.TransactionStatus;
import com.aia.wallet.enums.TransactionType;
import com.aia.wallet.repository.RewardTransactionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@ActiveProfiles("test")
class RewardServiceTest {

    @Autowired
    private RewardService rewardService;

    @Autowired
    private RewardTransactionRepository rewardTransactionRepository;

    @BeforeEach
    void setUp() {
        rewardTransactionRepository.deleteAll();

        // 1. Initial Credit: +1000
        RewardTransaction tx1 = new RewardTransaction();
        tx1.setUserId("user1");
        tx1.setTransactionType(TransactionType.Credit);
        tx1.setAmount(new BigDecimal("1000.00"));
        tx1.setCurrency("MMK");
        tx1.setTransactionDate(LocalDate.now().minusDays(2));
        tx1.setStatus(TransactionStatus.SUCCESS);
        tx1.setRequestedBy("Admin");
        rewardTransactionRepository.save(tx1);

        // 2. Debit: 200 (Logic will treat it as negative)
        RewardTransaction tx2 = new RewardTransaction();
        tx2.setUserId("user1");
        tx2.setTransactionType(TransactionType.Debit);
        tx2.setAmount(new BigDecimal("200.00"));
        tx2.setCurrency("MMK");
        tx2.setTransactionDate(LocalDate.now().minusDays(1));
        tx2.setStatus(TransactionStatus.SUCCESS);
        tx2.setRequestedBy("User");
        rewardTransactionRepository.save(tx2);

        // 3. Failed Transaction (Should be ignored)
        RewardTransaction tx3 = new RewardTransaction();
        tx3.setUserId("user1");
        tx3.setTransactionType(TransactionType.Credit);
        tx3.setAmount(new BigDecimal("500.00"));
        tx3.setCurrency("MMK");
        tx3.setTransactionDate(LocalDate.now());
        tx3.setStatus(TransactionStatus.FAILED);
        tx3.setRequestedBy("Admin");
        rewardTransactionRepository.save(tx3);
        
        // 4. Another user (Should not affect user1)
        RewardTransaction tx4 = new RewardTransaction();
        tx4.setUserId("user2");
        tx4.setTransactionType(TransactionType.Credit);
        tx4.setAmount(new BigDecimal("999.00"));
        tx4.setCurrency("MMK");
        tx4.setStatus(TransactionStatus.SUCCESS);
        tx4.setRequestedBy("Admin");
        rewardTransactionRepository.save(tx4);
    }

    @Test
    void testGetBalance() {
        BalanceResponse balance = rewardService.getBalance("user1");
        
        assertNotNull(balance);
        assertEquals("user1", balance.getUserId());
        assertEquals(new BigDecimal("800.00"), balance.getBalance()); // 1000 - 200
        assertEquals("MMK", balance.getCurrency());
        assertNotNull(balance.getLastUpdatedAt());
    }
    
    @Test
    void testGetBalance_UserNotFound() {
        BalanceResponse balance = rewardService.getBalance("non_existent_user");
        
        assertNotNull(balance);
        assertEquals("non_existent_user", balance.getUserId());
        assertEquals(BigDecimal.ZERO, balance.getBalance());
        assertNull(balance.getLastUpdatedAt());
    }

    @Test
    void testGetTransactionHistory() {
        List<TransactionResponse> history = rewardService.getTransactionHistory("user1");
        
        assertNotNull(history);
        assertEquals(2, history.size()); // Only 2 SUCCESS transactions
        
        // Verify order (DESC by date/update)
        // Note: Our service sorts by TransactionDate DESC.
        // tx2 is yesterday, tx1 is 2 days ago. So tx2 should be first.
        
        TransactionResponse first = history.get(0);
        assertEquals(new BigDecimal("200.00"), first.getAmount());
        assertEquals("Debit", first.getTransactionType());
        
        TransactionResponse second = history.get(1);
        assertEquals(new BigDecimal("1000.00"), second.getAmount());
        assertEquals("Credit", second.getTransactionType());
    }
}
